This folder stores all the chat history of clients running on the current computer. 
